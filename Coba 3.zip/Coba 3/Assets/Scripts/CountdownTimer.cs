using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class CountdownTimer : MonoBehaviour
{
    public Text countdownText;
    public float countdownTime = 3.0f;  // Waktu countdown awal (detik)
    private float currentTime;
    // Start is called before the first frame update
    void Start()
    {
        currentTime = countdownTime;
        UpdateCountdownText();
    }

    // Update is called once per frame
    void Update()
    {
        if (currentTime > 0)
        {
            currentTime -= Time.deltaTime;
            UpdateCountdownText();
        }
		
		if (currentTime <= 0)
        {
            SceneManager.LoadScene("Failed");
        }
    
    }
     void UpdateCountdownText()
    {
        int seconds = Mathf.CeilToInt(currentTime);
        countdownText.text = seconds.ToString();
    }
}